package Game;

import java.util.*;

public class Table {
	//each player will have sets of "hands" (played cards)
	ArrayList < ArrayList<Hand> > _plays;
	
	/*
	 * construct a table
	 */
	public Table(int numPlayers){
		this._plays = new ArrayList< ArrayList<Hand>>();
	}
	
	
}
