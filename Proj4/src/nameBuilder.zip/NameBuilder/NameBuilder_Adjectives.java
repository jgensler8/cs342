package NameBuilder;

public interface NameBuilder_Adjectives {
	public final String _Adjectives[] = {
			"Happy",		"Confused",			"Dazed",
			"Light-Headed",	"Understanding",	"Great",
			"Playful",		"Calm",				"Confident",
			"Courageous",	"Peaceful",			"Reliable",
			"Joyous",		"Energetic",		"At-Ease",
			"Lucky",		"Liberated",		"Comfortable",
			"Amazed",		"Fortunate",		"Optimistic",
			"Pleased",		"Delighted",		"Provocative",
			"Sympathetic",	"Overjoyed",		"Impulsive",
			"Clever",		"Interested",		"Gleeful",
			"Surprised",	"Satisfied",		"Frisky",
			"Content",		"Receptive",		"Animated",
			"Quiet",		"Accepting",		"Festive",
			"Spirited",		"Certain",			"Kind",
			"Ecstatic",		"Thrilled",			"Relaxed",
			"Satisfied",	"Wonderful",		"Serene",
			"Glad",			"Cheerful",			"Bright",
			"Sunny",		"Blessed",			"Merry",
			"Reassured",	"Elated",			"Jubilant",
			"Irritated",	"Enraged",			"Hostile",
			"Upset",		"Bitter",			"Boiling",
			"Shy",			"Stupefied",		"Tense",
			"Sulky",		"Indignant"
	};
}
